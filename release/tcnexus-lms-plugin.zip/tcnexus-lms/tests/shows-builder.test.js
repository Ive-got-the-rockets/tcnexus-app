const assert = require('node:assert/strict');
const fs = require('node:fs');

const builder = fs.readFileSync(
  require('node:path').join(__dirname, '..', 'includes', 'class-tcnexus-course-builder.php'),
  'utf8'
);
const postTypes = fs.readFileSync(
  require('node:path').join(__dirname, '..', 'includes', 'class-tcnexus-post-types.php'),
  'utf8'
);

assert.match(builder, /tcnexus-show-builder/);
assert.match(builder, /tc_show/);
assert.match(builder, /tcnexus_show_characters/);
assert.match(builder, /shows/);
assert.match(builder, /\$_GET\['builder_mode'\]/);
assert.match(postTypes, /register_post_type\( 'tc_show'/);
