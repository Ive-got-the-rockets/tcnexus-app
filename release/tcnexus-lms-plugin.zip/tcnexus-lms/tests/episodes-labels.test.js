const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const builder = fs.readFileSync(path.join(__dirname, '..', 'includes', 'class-tcnexus-course-builder.php'), 'utf8');
const globalList = fs.readFileSync(path.join(__dirname, '..', 'includes', 'class-tcnexus-global-lessons.php'), 'utf8');

assert.match(builder, />Episodes</);
assert.match(builder, /\+ Add Episode/);
assert.match(globalList, />Global Episodes List</);
